CREATE VIEW view_role_user AS
  SELECT DISTINCT
    `dmlweb_shiro`.`t_role`.`id`           AS `id`,
    `dmlweb_shiro`.`t_role`.`name`         AS `name`,
    `dmlweb_shiro`.`t_role`.`sn`           AS `sn`,
    `dmlweb_shiro`.`t_user_role`.`user_id` AS `user_id`
  FROM (`dmlweb_shiro`.`t_user_role`
    LEFT JOIN `dmlweb_shiro`.`t_role` ON ((`dmlweb_shiro`.`t_role`.`id` = `dmlweb_shiro`.`t_user_role`.`role_id`)));
