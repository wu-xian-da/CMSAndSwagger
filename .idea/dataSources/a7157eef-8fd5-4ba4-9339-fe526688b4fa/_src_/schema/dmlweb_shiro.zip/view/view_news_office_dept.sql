CREATE VIEW view_news_office_dept AS
  SELECT
    `a`.`id`          AS `id`,
    `a`.`create_id`   AS `create_id`,
    `d`.`staffname`   AS `create_name`,
    `d`.`deptId`      AS `create_dept_id`,
    `d`.`deptname`    AS `create_dept_name`,
    `a`.`create_time` AS `create_time`,
    `a`.`files`       AS `files`,
    `a`.`title`       AS `title`,
    `a`.`content`     AS `content`,
    `a`.`count`       AS `count`,
    `a`.`office_id`   AS `office_id`,
    `b`.`dept_id`     AS `dept_id`,
    `b`.`name`        AS `office_name`,
    `c`.`code`        AS `dept_code`,
    `c`.`name`        AS `dept_name`,
    `c`.`parantid`    AS `dept_parant_id`
  FROM (((`dmlweb_shiro`.`cms_news` `a` LEFT JOIN `dmlweb_shiro`.`cms_office` `b`
      ON ((`a`.`office_id` = `b`.`id`))) LEFT JOIN `dmlweb_shiro`.`t_dept` `c`
      ON ((`c`.`id` = `b`.`dept_id`))) LEFT JOIN `dmlweb_shiro`.`view_news_1` `d` ON ((`a`.`create_id` = `d`.`id`)))
  ORDER BY 5 DESC;
