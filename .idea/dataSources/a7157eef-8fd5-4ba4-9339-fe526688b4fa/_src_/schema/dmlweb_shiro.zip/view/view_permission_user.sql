CREATE VIEW view_permission_user AS
  SELECT
    `dmlweb_shiro`.`t_permission`.`id`         AS `id`,
    `dmlweb_shiro`.`t_permission`.`name`       AS `name`,
    `dmlweb_shiro`.`t_permission`.`menuname`   AS `menuname`,
    `dmlweb_shiro`.`t_permission`.`permission` AS `permission`,
    `dmlweb_shiro`.`t_permission`.`url`        AS `url`,
    `dmlweb_shiro`.`t_permission`.`flag`       AS `flag`,
    `dmlweb_shiro`.`t_permission`.`zindex`     AS `zindex`,
    `dmlweb_shiro`.`t_permission`.`parantid`   AS `parantid`,
    `dmlweb_shiro`.`t_user_role`.`user_id`     AS `userid`
  FROM ((`dmlweb_shiro`.`t_user_role`
    LEFT JOIN `dmlweb_shiro`.`t_role_permission`
      ON ((`dmlweb_shiro`.`t_user_role`.`role_id` = `dmlweb_shiro`.`t_role_permission`.`role_id`))) LEFT JOIN
    `dmlweb_shiro`.`t_permission`
      ON ((`dmlweb_shiro`.`t_role_permission`.`permission_id` = `dmlweb_shiro`.`t_permission`.`id`)));
