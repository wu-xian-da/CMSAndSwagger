CREATE VIEW view_news_1 AS
  SELECT
    `dmlweb_shiro`.`t_user`.`id`        AS `id`,
    `dmlweb_shiro`.`t_user`.`dept_id`   AS `dept_id`,
    `dmlweb_shiro`.`t_user`.`staffname` AS `staffname`,
    `dmlweb_shiro`.`t_user`.`username`  AS `username`,
    `dmlweb_shiro`.`t_user`.`password`  AS `password`,
    `dmlweb_shiro`.`t_user`.`status`    AS `status`,
    `dmlweb_shiro`.`t_dept`.`name`      AS `deptname`,
    `dmlweb_shiro`.`t_role`.`name`      AS `rolename`,
    `dmlweb_shiro`.`t_role`.`id`        AS `roleId`,
    `dmlweb_shiro`.`t_dept`.`id`        AS `deptId`
  FROM (((`dmlweb_shiro`.`t_user`
    LEFT JOIN `dmlweb_shiro`.`t_dept` ON ((`dmlweb_shiro`.`t_user`.`dept_id` = `dmlweb_shiro`.`t_dept`.`id`))) LEFT JOIN
    `dmlweb_shiro`.`t_user_role` ON ((`dmlweb_shiro`.`t_user`.`id` = `dmlweb_shiro`.`t_user_role`.`user_id`))) LEFT JOIN
    `dmlweb_shiro`.`t_role` ON ((`dmlweb_shiro`.`t_user_role`.`role_id` = `dmlweb_shiro`.`t_role`.`id`)));
