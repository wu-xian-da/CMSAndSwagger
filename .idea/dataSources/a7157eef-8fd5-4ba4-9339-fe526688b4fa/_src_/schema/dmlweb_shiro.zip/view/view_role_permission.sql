CREATE VIEW view_role_permission AS
  SELECT
    `dmlweb_shiro`.`t_role`.`id`               AS `id`,
    `dmlweb_shiro`.`t_role`.`name`             AS `name`,
    `dmlweb_shiro`.`t_role`.`sn`               AS `sn`,
    `dmlweb_shiro`.`t_permission`.`id`         AS `permissionId`,
    `dmlweb_shiro`.`t_permission`.`name`       AS `permissionname`,
    `dmlweb_shiro`.`t_permission`.`menuname`   AS `menuname`,
    `dmlweb_shiro`.`t_permission`.`permission` AS `permission`,
    `dmlweb_shiro`.`t_permission`.`url`        AS `url`,
    `dmlweb_shiro`.`t_permission`.`flag`       AS `flag`,
    `dmlweb_shiro`.`t_permission`.`zindex`     AS `zindex`,
    `dmlweb_shiro`.`t_permission`.`parantid`   AS `parantid`
  FROM ((`dmlweb_shiro`.`t_role`
    LEFT JOIN `dmlweb_shiro`.`t_role_permission`
      ON ((`dmlweb_shiro`.`t_role`.`id` = `dmlweb_shiro`.`t_role_permission`.`role_id`))) LEFT JOIN
    `dmlweb_shiro`.`t_permission`
      ON ((`dmlweb_shiro`.`t_role_permission`.`permission_id` = `dmlweb_shiro`.`t_permission`.`id`)));
